#!/bin/bash

java -classpath AzulInspector.jar azulinspector.EnvCheck | tee `hostname`-AzulSystemQual.`date +%F-%H%M`.log

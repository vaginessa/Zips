/**
 * Written by Gil Tene of Azul Systems, and released to the public domain,
 * as explained at http://creativecommons.org/publicdomain/zero/1.0/
 *
 * @author Gil Tene
 */

package org.jhiccup;

public final class Version {
    public static final String version="2.0.10";
    public static final String build_time="2018-10-06T17:07:08Z";
}
